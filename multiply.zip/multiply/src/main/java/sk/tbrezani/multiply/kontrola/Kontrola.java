package sk.tbrezani.multiply.kontrola;

import sk.tbrezani.multiply.exception.ExceptionMuchParameters;
import sk.tbrezani.multiply.exception.ExceptionNumber1IsNotInteger;
import sk.tbrezani.multiply.exception.ExceptionNumber2IsNotInteger;

import java.math.BigDecimal;
import java.math.BigInteger;

public class Kontrola {

    public static void pocetParametorov(String[] args) {
        if(args.length>4){
            throw new ExceptionMuchParameters("Zadali ste viac argumentov ako 4");
        }
    }


    public static void JeHodnotaCeleCislo(String alg, String number1, String number2) {
        if (alg.equals("alg1")) {
            try {
                BigInteger bigInteger = new BigInteger(number1);
            } catch (Exception e) {
                throw new ExceptionNumber1IsNotInteger("Prva hodnota nie je cele cislo");
            }
            try {
                BigInteger bigInteger2 = new BigInteger(number2);
            } catch (Exception e) {
                throw new ExceptionNumber2IsNotInteger("Druha hodnota nie je cele cislo");
            }
        }
        if (alg.equals("alg2")) {
            try {
                BigDecimal bigDecimal1 = new BigDecimal(number1);
                if (bigDecimal1.scale()!=0)
                    throw new ExceptionNumber1IsNotInteger("Prva hodnota nie je cele cislo");
            } catch (Exception e) {
                throw new ExceptionNumber1IsNotInteger("Prva hodnota nie je cele cislo");
            }
            try {
                BigDecimal bigDecimal2= new BigDecimal(number2);
                if (bigDecimal2.scale()!=0)
                    throw new ExceptionNumber2IsNotInteger("Druha hodnota nie je cele cislo");
            } catch (Exception e) {
                throw new ExceptionNumber2IsNotInteger("Druha hodnota nie je cele cislo");
            }

        }
    }
}
