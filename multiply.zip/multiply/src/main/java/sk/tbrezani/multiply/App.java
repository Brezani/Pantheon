package sk.tbrezani.multiply;

import picocli.CommandLine;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;
import picocli.CommandLine.Parameters;
import sk.tbrezani.multiply.algoritmi.Nasob;
import sk.tbrezani.multiply.kontrola.Kontrola;

import java.util.concurrent.Callable;

/**
 * Hello world!
 *
 */
@Command()
public class App implements Callable<Integer>
{
    @Option(names = {"-a", "--algoritmus" },description = "alg1 alg2")
     private String alg ="alg1" ;

    @Parameters( index = "0", paramLabel = "number1", description = "prva hodnota")
    String number1;

    @Parameters(index = "1",paramLabel = "number2", description = "druha hodnota")
    String number2="546";



    @Override
    public Integer call() throws Exception {

        Kontrola.JeHodnotaCeleCislo(alg,number1,number2);

        if (alg.equals("alg1"))
            System.out.println(Nasob.algoritmus1(number1,number2));
        if (alg.equals("alg2"))
            System.out.println(Nasob.algoritmus2(number1,number2));
        return 0;
    }


    public static void main( String[] args )
    {
        Kontrola.pocetParametorov(args);

        int exitCode = new CommandLine(new App()).execute(args);
        System.exit(exitCode);

//        Scanner s = new Scanner(System.in);
//
//        while (true){
//            String input  = s.nextLine();
//            if (input.equalsIgnoreCase("q"))
//                break;
//            System.out.println(input);
//        }
//        s.close();


    }
}
