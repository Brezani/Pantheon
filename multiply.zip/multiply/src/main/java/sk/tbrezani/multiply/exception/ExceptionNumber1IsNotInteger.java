package sk.tbrezani.multiply.exception;

public class ExceptionNumber1IsNotInteger extends RuntimeException {
    public ExceptionNumber1IsNotInteger(String s) {
        super(s);
    }
}
