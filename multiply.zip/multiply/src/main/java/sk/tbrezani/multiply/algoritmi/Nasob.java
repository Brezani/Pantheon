package sk.tbrezani.multiply.algoritmi;

import java.math.BigDecimal;
import java.math.BigInteger;

public class Nasob {
    public static String algoritmus1(String number1, String number2) {
        BigInteger bigInteger1 = new BigInteger(number1);
        BigInteger bigInteger2 = new BigInteger(number2);

        return bigInteger1.multiply(bigInteger2).toString();
    }

    public static String algoritmus2(String number1, String number2) {
        BigDecimal bigDecimal1 = new BigDecimal(number1);
        BigDecimal bigDecimal2 = new BigDecimal(number2);

        return bigDecimal1.multiply(bigDecimal2).toString();
    }
}
