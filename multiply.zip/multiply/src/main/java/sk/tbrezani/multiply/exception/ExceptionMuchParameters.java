package sk.tbrezani.multiply.exception;

public class ExceptionMuchParameters extends RuntimeException {
    public ExceptionMuchParameters(String s) {
        super(s);
    }
}
