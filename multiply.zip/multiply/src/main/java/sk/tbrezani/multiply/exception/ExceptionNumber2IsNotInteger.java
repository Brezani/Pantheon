package sk.tbrezani.multiply.exception;

public class ExceptionNumber2IsNotInteger extends RuntimeException {
    public ExceptionNumber2IsNotInteger(String s) {
        super(s);
    }
}
