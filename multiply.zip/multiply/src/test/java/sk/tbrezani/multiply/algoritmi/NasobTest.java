package sk.tbrezani.multiply.algoritmi;

import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class NasobTest {
    @Test
    public void porovnajVysledkyAlg1AAlg2(){
        String number1 = ("12345678901234567890");
        String number2 = ("1111111111111111111111");

        String alg1 = Nasob.algoritmus1(number1,number2);
        String alg2 = Nasob.algoritmus2(number1,number2);

        assertEquals(alg1,alg2);

    }
}
